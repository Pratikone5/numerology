import React from "react";


import Link from "next/link";


export function SubPara(props) {
    return (
      <p
        className={`${props.extra} dark:text-zinc-300 text-zinc-700 text-[15px] md:text-lg`}
      >
        {props.children}
      </p>
    );
  }

export default function BiorythmLandingPage({ formdata }) {
  const color = [
    "bg-gradient-to-tl from-blue-200 to-sky-100/60",
    "bg-gradient-to-tl from-amber-200/60 to-yellow-100/50",
    "bg-gradient-to-tl from-fuchsia-200 to-violet-50",
  ];
  const handleTheme = (e) => {
    const { checked } = e.target;
    if (checked) {
    
      localStorage.theme = "dark";
    } else {
  
      localStorage.theme = "light";
    }
    document.documentElement.classList.toggle("dark");
  };







  return (
    <div>
      <style jsx>
        {`
          .hero {
            position: relative;
            z-index: 1;
          }
          .hero:before {
            position: absolute;
            content: " ";
            width: 1000px;
            top: -100px;
            opacity: 0.5;
            z-index: -1;
            left: -600px;
            height: 1000px;
            background-image: url("/imgs/red_gradient.svg");
            background-size: cover;
            background-position: left;
          }
        `}
      </style>








      <div className=" fixed top-5 md:top-7 max-w-max w-full  right-5 md:right-7 z-[2]  flex justify-end">
        <label
          htmlFor="toggle-example"
          className="flex items-center cursor-pointer relative "
        >
          <input
          
            onChange={handleTheme}
            type="checkbox"
            id="toggle-example"
            className="sr-only switcher "
          />
          <div className="toggle-bg bg-gray-200 border-2 border-gray-200 h-6 w-11 rounded-full" />
        </label>
      </div>
      
      <div className="dark:bg-[#2F2F31] md:pt-16 md:pb-20 py-14 bg-zinc-100">
        <div className="max-w-4xl mx-auto flex flex-col gap-5">
          <h1
            style={{ lineHeight: 1.3 }}
            className="bg-clip-text  text-transparent bg-gradient-to-l from-orange-400 to-rose-400   md:text-6xl text-4xl font-cera_bold text-center"
          >
            {staticData.section1.title}
          </h1>
          <SubPara extra="max-w-2xl font-semibold mx-auto text-center">
          Use our free destiny number calculator to find your path to success! Explore your innate talents and character traits to know your full potential and achieve greatness!






          </SubPara>

          <div className="w-full mt-5 flex justify-center">
             <form className="max-w-xl  mx-auto mt-10 bg-gray-50 shadow-lg dark:shadow-zinc-900 dark:bg-zinc-800 p-6 sm:p-10 rounded-md w-full flex flex-col gap-8 md:gap-12 dark:text-zinc-100">
<div className="w-full flex relative flex-col pt-2 gap-4 ">
<input type="text" placeholder=" " id="name" name="name" className="w-full py-2   st bg-transparent text-zinc-800 dark:text-zinc-100 border-b-2 border-zinc-400  focus:border-sky-500      " value=""/>
<label for="name" className="whitespace-nowrap labelt text-lg">Enter your name</label>
</div>
<div className="w-full flex flex-col gap-4 ">
<div className="grid grid-cols-4 gap-5 sm:items-center w-full dark:text-zinc-200">
<div className="flex col-span-2 items-center w-full gap-5">
<select name="month" className="text-gray-500 dark:text-zinc-100 dark:bg-zinc-800 py-3 border-b-2 w-full bg-transparent  focus:border-sky-500 focus:outline-none border-zinc-400">
<option value="true">Birth Month</option>
<option value="1">January</option>
<option value="2">February</option>
<option value="3">March</option>
<option value="4">April</option>
<option value="5">May</option>
<option value="6">June</option>
<option value="7">July</option>
<option value="8">August</option>
<option value="9">September</option>
<option value="10">October</option>
<option value="11">November</option>
<option value="12">December</option>
</select>
</div>
<div className="w-full flex relative flex-col pt-2 gap-4 ">
<input type="number" placeholder=" " min="1" max="31" id="day" name="day" className="w-full st bg-transparent py-2 text-zinc-800 dark:text-zinc-100 border-b-2 border-zinc-400  focus:border-sky-500    " value=""/>
<label for="day" className="whitespace-nowrap labelt text-lg">DD</label>
</div>
<div className="w-full flex relative flex-col pt-2 gap-4 ">
<input type="number" placeholder=" " min="1900" max="2050" id="year" name="year" className="w-full st bg-transparent py-2 text-zinc-800 dark:text-zinc-100 border-b-2 border-zinc-400  focus:border-sky-500    " value=""/>
<label for="year" className="whitespace-nowrap labelt text-lg">YYYY</label>
</div>
</div>
</div>
<div className="w-full flex-col flex gap-5">
<label for="hour" className="whitespace-nowrap font-cera_bold text-lg">Time of birth:</label>
<div className="flex w-full gap-5">
<div className="w-full">
<select name="hour" id="hour" className="text-gray-500 bg-transparent dark:text-zinc-100 dark:bg-zinc-800 py-3 border-b-2 w-full focus:border-sky-500 focus:outline-none border-zinc-400">
<option value="true">Birth Hour</option>
<option value="0">00 (12 midnight)</option>
<option value="1">01 (am)</option>
<option value="2">02 (am)</option>
<option value="3">03 (am)</option>
<option value="4">04 (am)</option>
<option value="5">05 (am)</option>
<option value="6">06 (am)</option>
<option value="7">07 (am)</option>
<option value="8">08 (am)</option>
<option value="9">09 (am)</option>
<option value="10">10 (am)</option>
<option value="11">11 (am)</option>
<option value="12">12 (noon)</option>
<option value="13">13 (1 pm)</option>
<option value="14">14 (2 pm)</option>
<option value="15">15 (3 pm)</option>
<option value="16">16 (4 pm)</option>
<option value="17">17 (5 pm)</option>
<option value="18">18 (6 pm)</option>
<option value="19">19 (7 pm)</option>
<option value="20">20 (8 pm)</option>
<option value="21">21 (9 pm)</option>
<option value="22">22 (10 pm)</option>
<option value="23">23 (11 pm)</option>
</select>
</div>
<div className="w-full">
<select name="min" className="text-gray-500 bg-transparent dark:text-zinc-100 dark:bg-zinc-800 py-3 border-b-2 w-full  focus:border-sky-500 focus:outline-none border-zinc-400">
<option value="true">Birth Minute</option>
<option value="0">00</option>
<option value="1">01</option>
<option value="2">02</option>
<option value="3">03</option>
<option value="4">04</option>
<option value="5">05</option>
<option value="6">06</option>
<option value="7">07</option>
<option value="8">08</option>
<option value="9">09</option>
<option value="10">10</option>
<option value="11">11</option>
<option value="12">12</option>
<option value="13">13</option>
<option value="14">14</option>
<option value="15">15</option>
<option value="16">16</option>
<option value="17">17</option>
<option value="18">18</option>
<option value="19">19</option>
<option value="20">20</option>
<option value="21">21</option>
<option value="22">22</option>
<option value="23">23</option>
<option value="24">24</option>
<option value="25">25</option>
<option value="26">26</option>
<option value="27">27</option>
<option value="28">28</option>
<option value="29">29</option>
<option value="30">30</option>
<option value="31">31</option>
<option value="32">32</option>
<option value="33">33</option>
<option value="34">34</option>
<option value="35">35</option>
<option value="36">36</option>
<option value="37">37</option>
<option value="38">38</option>
<option value="39">39</option>
<option value="40">40</option>
<option value="41">41</option>
<option value="42">42</option>
<option value="43">43</option>
<option value="44">44</option>
<option value="45">45</option>
<option value="46">46</option>
<option value="47">47</option>
<option value="48">48</option>
<option value="49">49</option>
<option value="50">50</option>
<option value="51">51</option>
<option value="52">52</option>
<option value="53">53</option>
<option value="54">54</option>
<option value="55">55</option>
<option value="56">56</option>
<option value="57">57</option>
<option value="58">58</option>
<option value="59">59</option>
</select>
</div>
</div>
</div>
<div>
<div className="flex flex-col gap-5 sm:gap-6">
<label className="text-lg font-cera_bold">Select your birth place:</label>
<div className="w-full flex gap-6 md:gap-7 sm:flex-row flex-col items-end">
<div className=" w-full sm:max-w-max">
<select id="country" name="country" className="w-full sm:w-[170px] dark:bg-zinc-800 bg-zinc-50 truncate pr-3 selectCountry text-zinc-800 dark:text-zinc-100 border-b-2 border-zinc-400 focus:border-sky-500 py-2 ">
<option value="Afghanistan">Afghanistan</option>
<option value="Akrotiri">Akrotiri</option>
<option value="Albania">Albania</option>
<option value="Algeria">Algeria</option>
<option value="American Samoa">American Samoa</option>
<option value="Andorra">Andorra</option>
<option value="Angola">Angola</option>
<option value="Anguilla">Anguilla</option>
<option value="Antigua And Barbuda">Antigua And Barbuda</option>
<option value="Argentina">Argentina</option>
<option value="Armenia">Armenia</option>
<option value="Aruba">Aruba</option>
<option value="Australia">Australia</option>
<option value="Austria">Austria</option>
<option value="Azerbaijan">Azerbaijan</option>
<option value="Bahamas, The">Bahamas, The</option>
<option value="Bahrain">Bahrain</option>
<option value="Bangladesh">Bangladesh</option>
<option value="Barbados">Barbados</option>
<option value="Belarus">Belarus</option>
<option value="Belgium">Belgium</option>
<option value="Belize">Belize</option>
<option value="Benin">Benin</option>
<option value="Bermuda">Bermuda</option>
<option value="Bhutan">Bhutan</option>
<option value="Bolivia">Bolivia</option>
<option value="Bosnia And Herzegovina">Bosnia And Herzegovina</option>
<option value="Botswana">Botswana</option>
<option value="Brazil">Brazil</option>
<option value="British Indian Ocean Territory">British Indian Ocean Territory</option>
<option value="Brunei">Brunei</option>
<option value="Bulgaria">Bulgaria</option>
<option value="Burkina Faso">Burkina Faso</option>
<option value="Burma">Burma</option>
<option value="Burundi">Burundi</option>
<option value="Cabo Verde">Cabo Verde</option>
<option value="Cambodia">Cambodia</option>
<option value="Cameroon">Cameroon</option>
<option value="Canada">Canada</option>
<option value="Cayman Islands">Cayman Islands</option>
<option value="Central African Republic">Central African Republic</option>
<option value="Chad">Chad</option>
<option value="Chile">Chile</option>
<option value="China">China</option>
<option value="Christmas Island">Christmas Island</option>
<option value="Cocos (Keeling) Islands">Cocos (Keeling) Islands</option>
<option value="Colombia">Colombia</option>
<option value="Comoros">Comoros</option>
<option value="Congo (Brazzaville)">Congo (Brazzaville)</option>
<option value="Congo (Kinshasa)">Congo (Kinshasa)</option>
<option value="Cook Islands">Cook Islands</option>
<option value="Costa Rica">Costa Rica</option>
<option value="Croatia">Croatia</option>
<option value="Cuba">Cuba</option>
<option value="Curaçao">Curaçao</option>
<option value="Cyprus">Cyprus</option>
<option value="Czechia">Czechia</option>
<option value="Côte D’Ivoire">Côte D’Ivoire</option>
<option value="Denmark">Denmark</option>
<option value="Dhekelia">Dhekelia</option>
<option value="Djibouti">Djibouti</option>
<option value="Dominica">Dominica</option>
<option value="Dominican Republic">Dominican Republic</option>
<option value="Ecuador">Ecuador</option>
<option value="Egypt">Egypt</option>
<option value="El Salvador">El Salvador</option>
<option value="Equatorial Guinea">Equatorial Guinea</option>
<option value="Eritrea">Eritrea</option>
<option value="Estonia">Estonia</option>
<option value="Ethiopia">Ethiopia</option>
<option value="Falkland Islands (Islas Malvinas)">Falkland Islands (Islas Malvinas)</option>
<option value="Faroe Islands">Faroe Islands</option>
<option value="Fiji">Fiji</option>
<option value="Finland">Finland</option>
<option value="France">France</option>
<option value="French Guiana">French Guiana</option>
<option value="French Polynesia">French Polynesia</option>
<option value="French Southern And Antarctic Lands">French Southern And Antarctic Lands</option>
<option value="Gabon">Gabon</option>
<option value="Gambia, The">Gambia, The</option>
<option value="Gaza Strip">Gaza Strip</option>
<option value="Georgia">Georgia</option>
<option value="Germany">Germany</option>
<option value="Ghana">Ghana</option>
<option value="Gibraltar">Gibraltar</option>
<option value="Greece">Greece</option>
<option value="Greenland">Greenland</option>
<option value="Grenada">Grenada</option>
<option value="Guadeloupe">Guadeloupe</option>
<option value="Guam">Guam</option>
<option value="Guatemala">Guatemala</option>
<option value="Guernsey">Guernsey</option>
<option value="Guinea">Guinea</option>
<option value="Guinea-Bissau">Guinea-Bissau</option>
<option value="Guyana">Guyana</option>
<option value="Haiti">Haiti</option>
<option value="Honduras">Honduras</option>
<option value="Hong Kong">Hong Kong</option>
<option value="Hungary">Hungary</option>
<option value="Iceland">Iceland</option>
<option value="India">India</option>
<option value="Indonesia">Indonesia</option>
<option value="Iran">Iran</option>
<option value="Iraq">Iraq</option>
<option value="Ireland">Ireland</option>
<option value="Isle Of Man">Isle Of Man</option>
<option value="Israel">Israel</option>
<option value="Italy">Italy</option>
<option value="Jamaica">Jamaica</option>
<option value="Japan">Japan</option>
<option value="Jersey">Jersey</option>
<option value="Jordan">Jordan</option>
<option value="Kazakhstan">Kazakhstan</option>
<option value="Kenya">Kenya</option>
<option value="Kiribati">Kiribati</option>
<option value="Korea, North">Korea, North</option>
<option value="Korea, South">Korea, South</option>
<option value="Kosovo">Kosovo</option>
<option value="Kuwait">Kuwait</option>
<option value="Kyrgyzstan">Kyrgyzstan</option>
<option value="Laos">Laos</option>
<option value="Latvia">Latvia</option>
<option value="Lebanon">Lebanon</option>
<option value="Lesotho">Lesotho</option>
<option value="Liberia">Liberia</option>
<option value="Libya">Libya</option>
<option value="Liechtenstein">Liechtenstein</option>
<option value="Lithuania">Lithuania</option>
<option value="Luxembourg">Luxembourg</option>
<option value="Macau">Macau</option>
<option value="Macedonia">Macedonia</option>
<option value="Madagascar">Madagascar</option>
<option value="Malawi">Malawi</option>
<option value="Malaysia">Malaysia</option>
<option value="Maldives">Maldives</option>
<option value="Mali">Mali</option>
<option value="Malta">Malta</option>
<option value="Marshall Islands">Marshall Islands</option>
<option value="Martinique">Martinique</option>
<option value="Mauritania">Mauritania</option>
<option value="Mauritius">Mauritius</option>
<option value="Mayotte">Mayotte</option>
<option value="Mexico">Mexico</option>
<option value="Micronesia, Federated States Of">Micronesia, Federated States Of</option>
<option value="Moldova">Moldova</option>
<option value="Monaco">Monaco</option>
<option value="Mongolia">Mongolia</option>
<option value="Montenegro">Montenegro</option>
<option value="Montserrat">Montserrat</option>
<option value="Morocco">Morocco</option>
<option value="Mozambique">Mozambique</option>
<option value="Namibia">Namibia</option>
<option value="Nauru">Nauru</option>
<option value="Nepal">Nepal</option>
<option value="Netherlands">Netherlands</option>
<option value="New Caledonia">New Caledonia</option>
<option value="New Zealand">New Zealand</option>
<option value="Nicaragua">Nicaragua</option>
<option value="Niger">Niger</option>
<option value="Nigeria">Nigeria</option>
<option value="Niue">Niue</option>
<option value="Norfolk Island">Norfolk Island</option>
<option value="Northern Mariana Islands">Northern Mariana Islands</option>
<option value="Norway">Norway</option>
<option value="Oman">Oman</option>
<option value="Pakistan">Pakistan</option>
<option value="Palau">Palau</option>
<option value="Panama">Panama</option>
<option value="Papua New Guinea">Papua New Guinea</option>
<option value="Paracel Islands">Paracel Islands</option>
<option value="Paraguay">Paraguay</option>
<option value="Peru">Peru</option>
<option value="Philippines">Philippines</option>
<option value="Pitcairn Islands">Pitcairn Islands</option>
<option value="Poland">Poland</option>
<option value="Portugal">Portugal</option>
<option value="Puerto Rico">Puerto Rico</option>
<option value="Qatar">Qatar</option>
<option value="Reunion">Reunion</option>
<option value="Romania">Romania</option>
<option value="Russia">Russia</option>
<option value="Rwanda">Rwanda</option>
<option value="Saint Barthelemy">Saint Barthelemy</option>
<option value="Saint Helena, Ascension, And Tristan Da Cunha">Saint Helena, Ascension, And Tristan Da Cunha</option>
<option value="Saint Kitts And Nevis">Saint Kitts And Nevis</option>
<option value="Saint Lucia">Saint Lucia</option>
<option value="Saint Martin">Saint Martin</option>
<option value="Saint Pierre And Miquelon">Saint Pierre And Miquelon</option>
<option value="Saint Vincent And The Grenadines">Saint Vincent And The Grenadines</option>
<option value="Samoa">Samoa</option>
<option value="San Marino">San Marino</option>
<option value="Sao Tome And Principe">Sao Tome And Principe</option>
<option value="Saudi Arabia">Saudi Arabia</option>
<option value="Senegal">Senegal</option>
<option value="Serbia">Serbia</option>
<option value="Seychelles">Seychelles</option>
<option value="Sierra Leone">Sierra Leone</option>
<option value="Singapore">Singapore</option>
<option value="Sint Maarten">Sint Maarten</option>
<option value="Slovakia">Slovakia</option>
<option value="Slovenia">Slovenia</option>
<option value="Solomon Islands">Solomon Islands</option>
<option value="Somalia">Somalia</option>
<option value="South Africa">South Africa</option>
<option value="South Georgia And South Sandwich Islands">South Georgia And South Sandwich Islands</option>
<option value="South Sudan">South Sudan</option>
<option value="Spain">Spain</option>
<option value="Spratly Islands">Spratly Islands</option>
<option value="Sri Lanka">Sri Lanka</option>
<option value="Sudan">Sudan</option>
<option value="Suriname">Suriname</option>
<option value="Svalbard">Svalbard</option>
<option value="Swaziland">Swaziland</option>
<option value="Sweden">Sweden</option>
<option value="Switzerland">Switzerland</option>
<option value="Syria">Syria</option>
<option value="Taiwan">Taiwan</option>
<option value="Tajikistan">Tajikistan</option>
<option value="Tanzania">Tanzania</option>
<option value="Thailand">Thailand</option>
<option value="Timor-Leste">Timor-Leste</option>
<option value="Togo">Togo</option>
<option value="Tokelau">Tokelau</option>
<option value="Tonga">Tonga</option>
<option value="Trinidad And Tobago">Trinidad And Tobago</option>
<option value="Tunisia">Tunisia</option>
<option value="Turkey">Turkey</option>
<option value="Turkmenistan">Turkmenistan</option>
<option value="Turks And Caicos Islands">Turks And Caicos Islands</option>
<option value="Tuvalu">Tuvalu</option>
<option value="U.S. Virgin Islands">U.S. Virgin Islands</option>
<option value="Uganda">Uganda</option>
<option value="Ukraine">Ukraine</option>
<option value="United Arab Emirates">United Arab Emirates</option>
<option value="United Kingdom">United Kingdom</option>
<option value="United States">United States</option>
<option value="Uruguay">Uruguay</option>
<option value="Uzbekistan">Uzbekistan</option>
<option value="Vanuatu">Vanuatu</option>
<option value="Venezuela">Venezuela</option>
<option value="Vietnam">Vietnam</option>
<option value="Virgin Islands, British">Virgin Islands, British</option>
<option value="Wallis And Futuna">Wallis And Futuna</option>
<option value="West Bank">West Bank</option>
<option value="Western Sahara">Western Sahara</option>
<option value="Yemen">Yemen</option>
<option value="Zambia">Zambia</option>
<option value="Zimbabwe">Zimbabwe</option>
</select>
</div>
<div className=" w-full">
<div className="w-full">
<div className="rbt  w-full no-scrollbar text-zinc-800 dark:text-zinc-100 bg-gray-50 dark:bg-zinc-800" tabindex="-1" >
<div >
<input autocomplete="off" placeholder="Type Birth City/District" type="text" aria-autocomplete="both" aria-expanded="false" aria-haspopup="listbox" role="combobox" className="rbt-input-main form-control rbt-input" value=""/>
<input aria-hidden="true" className="rbt-input-hint" readonly="" tabindex="-1" value="" />
</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div className="w-full flex flex-col gap-4">
<button type="submit" className="bg-sky-600 w-full hover:bg-sky-500 text-white font-cera_bold text-lg p-3 rounded-md ">Calculate Your Karma Number</button>
</div>
</form>
          </div>
        </div>
      </div>
      <div className="    dark:bg-zinc-900 px-5 md:py-24 py-14 ">
        <div className="max-w-3xl justify-center items-center flex flex-col gap-10 md:gap-14 w-full mx-auto">
          <h2
            style={{ lineHeight: 1.3 }}
            className="dark:text-white self-start font-cera_medium md:text-5xl text-3xl sm:text-4xl"
          >
            {staticData.section2.title}
          </h2>
          <div className="space-y-5">
          <SubPara extra="md:text-lg">{staticData.section2.desc[0]}</SubPara>
          <SubPara extra="md:text-lg">{staticData.section2.desc[1]}</SubPara>
          <SubPara extra="md:text-lg">{staticData.section2.desc[2]}</SubPara>
          <SubPara extra="md:text-lg">{staticData.section2.desc[3]}</SubPara>
          <SubPara extra="md:text-lg">{staticData.section2.desc[4]}</SubPara>
          </div>
          <h6 className="my-5 md:text-lg items-start cursor-pointer duration-100 ease-in hover:bg-blue-600 bg-blue-500 text-white mx-auto max-w-max  font-cera_medium rounded py-3 px-10">
                {staticData.section2.button_text2}
              </h6>
          



          
          
          {/* <div className="max-w-3xl mt-5 md:mt-10 flex flex-col gap-6 mx-auto">
            <h6 className="md:text-2xl dark:text-zinc-100 text-xl">
              {staticData.section2.title2}
            </h6>
            <SubPara extra="md:text-lg">{staticData.section2.desc}</SubPara>
            <h4 className="md:text-2xl dark:text-zinc-100 text-xl">
              {staticData.section2.title3}
            </h4>
            <SubPara extra="md:text-lg">{staticData.section2.desc2}</SubPara>
            <Link href="#kundliform">
              <h6 className="my-5 md:text-lg cursor-pointer duration-100 ease-in hover:bg-blue-600 bg-blue-500 text-white mx-auto max-w-max  font-cera_medium rounded py-3 px-10">
                {staticData.section2.button_text}
              </h6>
            </Link>
            {staticData.section2.desc3.map((item, i) => (
              <SubPara key={i} extra="md:text-lg">
                {item}
              </SubPara>
            ))}
            <Link href="#kundliform">
              <h6 className="my-5 md:text-lg text-center cursor-pointer duration-100 ease-in hover:bg-blue-600 bg-blue-500 text-white mx-auto max-w-max  font-cera_medium rounded py-3 px-10">
                {staticData.section2.button_text2}
              </h6>
            </Link>
          </div> */}
        </div>
      </div>
      <div className="dark:bg-[#2F2F31]    bg-zinc-100   ">
      <div className=" p-5 md:p-20  max-w-6xl mx-auto flex flex-col gap-10">
      <div className="py-5 md:py-20  px-0 md:px-10 flex flex-col  gap-10 md:gap-20 max-w-6xl mx-auto">
<div className=" flex md:flex-row flex-col gap-10 md:gap-20 items-center rounded-[30px]">
<div className="flex flex-col w-full gap-6 ">
<h2 className="font-cera_bold dark:text-white text-4xl font-semibold text-zinc-800 !leading-[1.3]">{staticData.section4.title}</h2>
<p className="md:text-lg text-[15px] dark:text-zinc-100  text-zinc-700">{staticData.section4.desc[0]}</p>
<p className="md:text-lg text-[15px] dark:text-zinc-100  text-zinc-700">{staticData.section4.desc[1]}</p>
</div>
<div className="w-full">
<img src="/destiny.svg" alt="simple understand" className="w-full"/>
</div>
</div>
</div>
<section>
<div className=" flex flex-col items-center mx-auto gap-10 md:gap-20 ">
<div className=" flex md:flex-row-reverse items-center flex-col gap-10 md:gap-20 rounded-[30px]">
<div className="flex items-start flex-col gap-6 w-full">

<p className="md:text-lg text-[15px] first-letter:font-bold first-letter:text-4xl dark:text-zinc-100 text-zinc-700 ">{staticData.section4.desc[2]}</p>
<p className="md:text-lg text-[15px] dark:text-zinc-100 text-zinc-700 ">{staticData.section4.desc[3]}</p>
<h6 className="self-start md:text-lg   cursor-pointer duration-100 ease-in hover:bg-blue-600 bg-blue-500 text-white mx-auto max-w-max  font-cera_medium rounded py-3 px-10 md:ml-3">
                {staticData.section2.button_text2}
              </h6>
</div>
<div className="w-full ">
<img src="/destiny.svg" alt="comprehensive relationship" className="w-full  "/>
</div>
</div>
</div>
</section>
</div>
      </div>
      <div className=" px-5 items-center dark:bg-zinc-900 md:py-24 py-14">
        <div className="max-w-5xl flex flex-col gap-10 md:gap-14 w-full mx-auto">
          <h2
            style={{ lineHeight: 1.3 }}
            className="md:text-5xl font-cera_medium dark:text-white text-center text-3xl sm:text-4xl"
          >
            {staticData.section5.title}
          </h2>
          
          <div className="max-w-3xl mx-auto items-center flex flex-col gap-10">
            
            <p className="text-xl dark:text-zinc-300 text-zinc-700">{staticData.section3.desc[0]}</p>
            <p className="text-xl dark:text-zinc-300 text-zinc-700"> {staticData.section3.desc[1]}</p>
            <p className="text-xl dark:text-zinc-300 text-zinc-700"> {staticData.section3.desc[2]}</p>
            <p className="text-xl dark:text-zinc-300 text-zinc-700"> {staticData.section3.desc[3]}</p>
            <p className="text-xl dark:text-zinc-300 text-zinc-700"> {staticData.section3.desc[4]}</p>

            <div className=" self-start dark:text-white ">
            <p className="px-10 ">1 — A, J, S.</p>
          <p className="px-10">2  — B, T, K.</p>
          <p className="px-10 ">3 — L, C, U.</p>
          <p className="px-10 ">4 — M, D, V.</p>
          <p className="px-10 ">5— N, E, W.</p>
          <p className="px-10 ">6 —  O, F, X..</p>
          <p className="px-10 ">7 — P, G, Y.</p>
          <p className="px-10 ">8 — Q, H, Z.</p>
          <p className="px-10 ">9 — M, D, V.</p>
            </div>
            <h6 className="my-5 md:text-lg text-center cursor-pointer duration-100 ease-in hover:bg-blue-600 bg-blue-500 text-white mx-auto max-w-max  font-cera_medium rounded py-3 px-10">
                {staticData.section2.button_text2}
              </h6>
           
          </div>

         
          
        </div>
      </div>
      
    
<div className="dark:bg-[#2F2F31]       bg-zinc-100 ">

<div className=" md:py-24 items-center py-14 px-5">
<div className=" max-w-6xl  items-center flex flex-col gap-7 mx-auto">
<div className="  flex flex-col gap-10">
<h2 className=" md:text-5xl font-bold  text-5xl dark:text-white">The Meaning of Destiny Number</h2>

</div>
<div className="max-w-2xl   pt-6 ">
<table role="table" className="w-full    max-w-2xl  border-zinc-300">
<thead>
<tr role="row">
<th colspan="2" className=" dark:text-gray-300 text-gray-800 text-left p-4 text-3xl" role="columnheader" >Destiny Number</th>



</tr>
</thead>
<tbody role="rowgroup">
<tr className="" role="row">
<td className="  border-zinc-300  text-[15px] bg-[#18181B ] dark:text-gray-300 text-gray-800 p-4" role="cell" >Destiny number 1 </td>
<td className=" border-zinc-300  text-[15px] bg-[#18181B ] dark:text-gray-300 text-gray-800 p-4" role="cell" >Cooperation, harmony, and balance.</td>
</tr>
<tr className="p-5" role="row">
<td className="  border-zinc-300 rounded-l-xl text-[15px] dark:text-gray-300 text-gray-800 dark:bg-orange-300/20 bg-orange-100 p-4" role="cell" >Destiny number 2 </td>
<td className=" border-zinc-300 rounded-r-xl text-[15px] dark:bg-orange-300/20 bg-orange-100 dark:text-gray-300 text-gray-800 p-4" role="cell" >Creativity, self-expression, and joy.</td>
</tr>
<tr role="row">
<td className=" border-zinc-300 rounded-l-xl  dark:text-gray-300 text-gray-800 text-[15px] te p-4" role="cell" >Destiny number 3 </td>
<td className=" border-zinc-300  rounded-r-xl dark:text-gray-300 text-gray-800 text-[15px] te p-4" role="cell" >Hard work, practicality, and stability</td>
</tr>
<tr role="row">
<td className=" border-zinc-300  rounded-l-xl  text-[15px] dark:bg-orange-300/20 bg-orange-100 dark:text-gray-300 text-gray-800 p-4" role="cell" >Destiny number 4 </td>
<td className=" border-zinc-300  rounded-r-xl  text-[15px] dark:bg-orange-300/20 bg-orange-100 dark:text-gray-300 text-gray-800  p-4" role="cell" >Leadership, independence, and individuality.</td>
</tr>
<tr role="row">
<td className=" border-zinc-300  rounded-l-xl text-[15px] dark:text-gray-300 text-gray-800 p-4" role="cell" >Destiny number 5 </td>
<td className=" border-zinc-300 rounded-r-xl text-[15px] dark:text-gray-300 text-gray-800 p-4" role="cell" >Freedom, change, and adventure.</td>
</tr>
<tr role="row">
<td className=" border-zinc-300  text-[15px] dark:bg-orange-300/20 bg-orange-100 rounded-l-xl dark:text-gray-300 text-gray-800 p-4" role="cell" >Destiny number 6 </td>
<td className=" border-zinc-300  text-[15px] dark:bg-orange-300/20 bg-orange-100 rounded-r-xl dark:text-gray-300 text-gray-800 p-4" role="cell" >Responsibility, nurturing, and harmony.</td>
</tr>
<tr role="row">
<td className=" border-zinc-300  rounded-l-xl text-[15px] dark:text-gray-300 text-gray-800 p-4" role="cell" >Destiny number 7 </td>
<td className=" border-zinc-300 rounded-r-xl text-[15px] dark:text-gray-300 text-gray-800 p-4" role="cell" >Analysis, spirituality, and wisdom..</td>
</tr>
<tr role="row">
<td className=" border-zinc-300  text-[15px] dark:bg-orange-300/20 bg-orange-100 rounded-l-xl dark:text-gray-300 text-gray-800 p-4" role="cell" >Destiny number 8 </td>
<td className=" border-zinc-300  text-[15px] dark:bg-orange-300/20 bg-orange-100 rounded-r-xl dark:text-gray-300 text-gray-800 p-4" role="cell" >Material success, abundance, and power.</td>
</tr>
<tr role="row">
<td className=" border-zinc-300  rounded-l-xl text-[15px] dark:text-gray-300 text-gray-800 p-4" role="cell" >Destiny number 9 </td>
<td className=" border-zinc-300 rounded-r-xl text-[15px] dark:text-gray-300 text-gray-800 p-4" role="cell" >Humanitarianism, compassion, and selflessness.</td>
</tr>











</tbody>

</table>
</div>

</div>
</div>
<div className="bg-white dark:bg-zinc-900">

     
      <div className=" max-w-5xl md:py-20 py-14 mx-auto">





</div>
<div className=" md:py-12 items-center  px-5">
<div className=" max-w-3xl  items-center flex flex-col gap-7 mx-auto">
<div className="  flex flex-col space-y-6 ">
<h2 className=" md:text-5xl font-bold  self-start text-5xl dark:text-white">The Meaning of Master Number</h2>
</div>
<p className="md:text-lg  dark:text-zinc-300 text-zinc-700">{staticData.section7.desc[0]} 
</p>
<p className="md:text-lg dark:text-zinc-300  text-zinc-700"> {staticData.section7.desc[1]}
</p>
<div className="max-w-2xl   pt-6 ">
<table role="table" className="w-full    max-w-3xl  border-zinc-300">
<thead>
<tr role="row">
<th colspan="3" className="dark:bg-[#18181B] text-gray-800 dark:text-gray-300 text-left p-4 text-3xl" role="columnheader" >Master Number</th>



</tr>
</thead>
<tbody role="rowgroup">
<tr className="" role="row">
<td className="  border-zinc-300  text-[15px] bg-[#18181B ] dark:text-gray-300 text-gray-800 p-4" role="cell" >Destiny number 11 </td>
<td className=" border-zinc-300  text-[15px] bg-[#18181B ] dark:text-gray-300 text-gray-800 p-3" role="cell" >Spiritual awakening, intuition, and creativity.</td>
</tr>
<tr className="p-5" role="row">
<td className="  border-zinc-300 rounded-l-xl text-[15px] dark:text-gray-300 bg-orange-100 text-gray-800 bg-ornge-100 dark:bg-orange-300/20 p-4" role="cell" >Destiny number 22 </td>
<td className=" border-zinc-300 rounded-r-xl text-[15px]  dark:bg-orange-300/20 bg-orange-100 dark:text-gray-300 text-gray-800 p-3" role="cell" >Building something significant, practicality, and philanthropy.</td>
</tr>
<tr role="row">
<td className=" border-zinc-300 rounded-l-xl w-xl dark:text-gray-300 text-gray-800 text-[15px] te p-4" role="cell" >Destiny number 33 </td>
<td className=" border-zinc-300  rounded-r-xl dark:text-gray-300 text-gray-800 text-[15px] te p-3" role="cell" >Master teacher, inspiration, and compassion for others..</td>
</tr>
</tbody>

</table>

</div>

</div>
</div>



</div>


</div>
    </div>
  );
}

const staticData = {
  section1: {
    title: "Destiny Number Calculator",
    desc: "Use Our Free Romantic Personality Calculator & Know Your Unique Traits in Love and Relationships",
    formTitle: "Free Biorhythm Calculator",
  },
  section2: {
    title:
      "About Destiny Number Calculator\n",
    desc: [
      "Have you ever wondered what your destiny holds? Your destiny number, also known as the expression number, is a powerful indicator of your unique traits and talents.",
      "Using our easy-to-use calculator, simply input your full, original birth-certificate name and let us do the rest. We'll calculate your destiny number and provide you with a detailed report on your strengths, weaknesses, and the path to your ultimate destiny.",
      "But that's not all. Your destiny number can also help you make important life decisions, such as choosing a career path, finding a partner, or making a major change in your life.",
      "Our calculator is completely free and easy to use. Plus, you'll receive your results instantly.",
      "So, what are you waiting for? Know the power of your destiny number today and get to know about your true potential. Use our free Destiny Number Calculator now!"
    ],
   
  
    button_text2: "Calculate Your Destiny Number\n",
  },

  section3 : {
    title: 
    "How to Calculate Destiny Number? ",
desc:[
  "To calculate your destiny number, you need to add up the numerical values of the letters in your full, original birth-certificate name. This is the name that was given to you at birth, regardless of whether you use it now or not.",
  "Once you have the total sum, you reduce it to a single-digit number by adding the digits together. This final number is your destiny number.",
  "For example, if your birth name is JOHN SMITH, you would assign the numerical value to each letter as follows:",
  "J=1, O=6, H=8, N=5, S=1, M=4, I=9, T=2, H=8 Then you add these values together: 1+6+8+5+1+4+9+2+8 = 44",
  "Since destiny numbers are single-digit numbers, you would further reduce 44 to 4+4 = 8",
  "Therefore, the destiny number for JOHN SMITH is 8."
]
    
  },

  section4: {
    title: "What is Destiny Number?",
    desc: [
      "Destiny number is a significant number that can help you achieve your goals, both big and small. It is also known as the expression number, and it differs from your life path number, which refers to your overall purpose in life. Your destiny number is more focused on your traits, character, and destiny. ",
      "Your destiny number is different from your life path number, which relates to your greater overall purpose. While your life path number tells you what you came to do, your destiny number describes how you will go about doing it. Both numbers can work hand in hand to guide you towards your ultimate destiny.",
      " To calculate your destiny number, you need to add up the numerical values of the letters in your full, original birth-certificate name. This is the name that was given to you at birth, regardless of whether you use it now or not. Your destiny number can help you understand the key traits and talents that you can use throughout your life.",
      "Your destiny number can guide you in choosing a career that is suitable for you. It can also help you make important life decisions, such as choosing a partner or making a major change in your life. Your destiny number can be seen as a road map that can help you find the right path that will lead you to happiness and contentment."
    ],
    title2: "Factors that Affect Biorhythm:\n",
    cards: [
      "<b className='font-cera_medium dark:text-white text-zinc-800 text-lg'>Planetary Positions</b>: Decipher how the planets' positions during your birth govern your Biorhythm cycles",
      "<b className='font-cera_medium dark:text-white text-zinc-800 text-lg'>Personal Habits</b>: Unravel how daily habits, like diet, exercise, sleep, and stress management, shape your Biorhythm status",
      "<b className='font-cera_medium dark:text-white text-zinc-800 text-lg'>External Environment</b>: Uncover how environmental factors, including climate, pollution, and social interactions, influence your Biorhythm status",
    ],
  },
  section5: {
    title: "How to Calculate Destiny Number?\n",
    cards: [
      "<b className='font-cera_medium  text-zinc-800 text-lg'>Physical Cycle</b>: Rule the physical aspects of your body, from the energy level and strength to resist, with this 23-day cycle. High points symbolize peak physical fitness, while low points reveal low energy and weakness.\n",
      "<b className='font-cera_medium  text-zinc-800 text-lg'>Emotional Cycle</b>: Master the emotional aspects of your life, from moods and creativity to sensitivity, with this 28-day cycle. High points signal positive emotions and heightened creativity, while low points indicate negative emotions and unproductivity.\n",
      "<b className='font-cera_medium  text-zinc-800 text-lg'>Intellectual Cycle</b>: Dominate the intellectual aspects of your life, including alertness, memory, and learning speed, with this 33-day cycle. High points mark mental sharpness and creativity, while low points reveal difficulty in understanding concepts and ideas.",
    ],
    title2: "What Happens If Biorhythm is Not Monitored?\n",
    list: [
      "Imbalance in physical, emotional, or intellectual aspects of life\n",
      "Plummeting productivity and creativity\n",
      "Health problems due to stress and fatigue\n",
      "Struggling relationships\n",
      "Overall life quality spirals down\n",
      "Don't let an unbalanced Biorhythm sabotage your dreams!",
    ],
    desc: [
      "Have you ever experienced oversleeping, walking into an important meeting with an un-ironed outfit, and limping from tripping over a curb on your way in?\n",
      "The Biorhythm Calculator could be the answer you seek!",
    ],
  },
  section6: {
    title2:
      "Embrace the opportunity to shape your destiny with the most precise Biorhythm Calculator at your fingertips",
    button_text2: "Discover Your Biorhythm",
  },
  section7: {
    title:
      "The Meaning of Master Number",
    desc: [
      "Master numbers are powerful numbers that are not reduced to a single digit like other numbers. The master numbers are 11, 22, and 33. These numbers are believed to have heightened spiritual vibrations and symbolize spiritual growth and enlightenment.",
      "People with master numbers in their numerology charts are considered to have special gifts and abilities and are often seen as leaders and visionaries. These numbers can be challenging to handle, but they also offer great potential for personal growth and spiritual development.",
      
    ],
    button_text: "Reveal Your Biorhythm Secret Now",
  },
};
